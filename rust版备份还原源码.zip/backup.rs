// ============================================================
// 备份与还原工具 (backup_restore.rs)
// ============================================================
//
// 功能概述:
//   提供文件备份、加密、分割、上传网盘及还原的完整解决方案，
//   支持本地和远程（123云盘）操作，具备文件头混淆、安全密码输入等特性。
//
// 使用说明请参考原脚本
// ============================================================

use std::env;
use std::fs::{self, File};
use std::io::{self, BufReader, Read, Write, Seek};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

use chrono::Local;
use dirs::home_dir;
use regex::Regex;
use serde_json::Value;
use tempfile::NamedTempFile;

// ============================================================
// 配置参数
// ============================================================
const TARGET_DIR: &str = "/storage/emulated/0/Download";
const BACKUP_DIR: &str = "backups";
const RESTORE_DIR: &str = "restored";
const TEMP_DIR: &str = "backups/tmp";
const RCLONE_REMOTE: &str = "123pan";
const RCLONE_PATH: &str = "/123pan";
const KEEP_LATEST: usize = 3;
const SPLIT_SIZE: &str = "100M";
const SPLIT_SUFFIX: &str = ".zip";
const ZSTD_LEVEL: &str = "3";
const COMPRESS_SPEED: &str = "250M";
const USER_AGENT: &str = "123pan/v2.5.5(Android 13;Xiaomi Mi Max 2)";
const BACKUP_PREFIX: &str = "llama.cpp_backup_";
const AUTO_UPLOAD: bool = true;
const OBFUSCATE_HEADER: bool = true;
const PBKDF2_ITER: &str = "1000000";
const CIPHER_ALG: &str = "aes-256-cbc";

// 伪装文件头 (ZIP 文件头)
const FAKE_FILE_HEADER: &[u8] = &[
    0x50, 0x4B, 0x03, 0x04, 0x14, 0x00, 0x00, 0x08,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
];

// ============================================================
// 数据结构
// ============================================================

#[derive(Debug, Clone)]
struct Config {
    target_dir: String,
    backup_dir: PathBuf,
    restore_dir: PathBuf,
    temp_dir: PathBuf,
    password: String,
    rclone_remote: String,
    rclone_path: String,
    keep_latest: usize,
    split_size: String,
    split_suffix: String,
    zstd_level: String,
    compress_speed: String,
    user_agent: String,
    backup_prefix: String,
    auto_upload: bool,
    obfuscate_header: bool,
    pbkdf2_iter: String,
    cipher_alg: String,
}

impl Default for Config {
    fn default() -> Self {
        let home = home_dir().unwrap_or_else(|| PathBuf::from("."));
        let backup_dir = home.join(BACKUP_DIR);
        let restore_dir = home.join(RESTORE_DIR);
        let temp_dir = home.join(TEMP_DIR);

        Config {
            target_dir: TARGET_DIR.to_string(),
            backup_dir,
            restore_dir,
            temp_dir,
            password: String::new(),
            rclone_remote: RCLONE_REMOTE.to_string(),
            rclone_path: RCLONE_PATH.to_string(),
            keep_latest: KEEP_LATEST,
            split_size: SPLIT_SIZE.to_string(),
            split_suffix: SPLIT_SUFFIX.to_string(),
            zstd_level: ZSTD_LEVEL.to_string(),
            compress_speed: COMPRESS_SPEED.to_string(),
            user_agent: USER_AGENT.to_string(),
            backup_prefix: BACKUP_PREFIX.to_string(),
            auto_upload: AUTO_UPLOAD,
            obfuscate_header: OBFUSCATE_HEADER,
            pbkdf2_iter: PBKDF2_ITER.to_string(),
            cipher_alg: CIPHER_ALG.to_string(),
        }
    }
}

#[derive(Debug)]
struct BackupInfo {
    name: String,
    size: String,
    mtime: String,
    is_local: bool,
}

// ============================================================
// 密码处理
// ============================================================

/// 安全地获取密码：交互式输入或使用默认密码
fn get_password(config: &mut Config, interactive: bool) -> Result<(), String> {
    if interactive {
        let password = prompt_password()?;
        config.password = password;
        Ok(())
    } else {
        config.password = String::new();
        println!("[*] 使用默认密码");
        Ok(())
    }
}

/// 交互式密码输入（不回显）
fn prompt_password() -> Result<String, String> {
    use rpassword::read_password;

    eprintln!("请输入密码: ");
    let pwd1 = read_password().map_err(|e| format!("读取密码失败: {}", e))?;

    if pwd1.is_empty() {
        return Err("错误: 密码不能为空".to_string());
    }

    eprintln!("请再次输入密码以确认: ");
    let pwd2 = read_password().map_err(|e| format!("读取密码失败: {}", e))?;

    if pwd1 != pwd2 {
        return Err("错误: 两次输入的密码不一致".to_string());
    }

    eprintln!("[*] 密码已安全设置。");
    Ok(pwd1)
}

/// 创建密码临时文件
fn create_password_tempfile(password: &str) -> Result<NamedTempFile, String> {
    let mut tempfile = NamedTempFile::new()
        .map_err(|e| format!("无法创建密码临时文件: {}", e))?;

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mut perms = tempfile.as_file().metadata()
            .map_err(|e| format!("获取文件权限失败: {}", e))?
            .permissions();
        perms.set_mode(0o600);
        fs::set_permissions(tempfile.path(), perms)
            .map_err(|e| format!("设置文件权限失败: {}", e))?;
    }

    write!(tempfile, "{}", password)
        .map_err(|e| format!("写入密码文件失败: {}", e))?;
    tempfile.flush()
        .map_err(|e| format!("刷新密码文件失败: {}", e))?;

    Ok(tempfile)
}

// ============================================================
// 文件头混淆
// ============================================================

/// 混淆文件头：将原始头部替换为伪装头，并在末尾存储原始头和偏移量
fn obfuscate_header(file_path: &Path) -> Result<(), String> {
    if !file_path.exists() {
        return Err(format!("目标文件不存在: {}", file_path.display()));
    }

    println!("[混淆] 正在处理: {}", file_path.file_name().unwrap_or_default().to_string_lossy());

    // 读取原始前16字节
    let mut file = File::open(file_path)
        .map_err(|e| format!("打开文件失败: {}", e))?;
    let mut original_header = [0u8; 16];
    file.read_exact(&mut original_header)
        .map_err(|e| format!("读取原始文件头失败: {}", e))?;

    // 检查是否已被混淆过 (ZIP 头检查)
    if original_header.starts_with(&[0x50, 0x4B, 0x03, 0x04]) {
        println!("[混淆] 文件已是指定伪装文件头，跳过混淆");
        return Ok(());
    }

    // 获取文件大小
    let orig_size = file.metadata()
        .map_err(|e| format!("获取文件大小失败: {}", e))?
        .len();

    // 写入伪装头
    file.seek(io::SeekFrom::Start(0))
        .map_err(|e| format!("定位文件开头失败: {}", e))?;
    file.write_all(FAKE_FILE_HEADER)
        .map_err(|e| format!("写入伪装文件头失败: {}", e))?;

    // 移动到文件末尾追加数据
    file.seek(io::SeekFrom::End(0))
        .map_err(|e| format!("定位文件末尾失败: {}", e))?;

    // 追加: 原始头(16字节) + 偏移量(8字节小端) + OBFS(4字节)
    file.write_all(&original_header)
        .map_err(|e| format!("写入原始头失败: {}", e))?;

    // 偏移量小端存储 (8字节)
    let offset_bytes = orig_size.to_le_bytes();
    file.write_all(&offset_bytes)
        .map_err(|e| format!("写入偏移量失败: {}", e))?;

    // 写入 "OBFS" 标记
    file.write_all(b"OBFS")
        .map_err(|e| format!("写入OBFS标记失败: {}", e))?;

    file.sync_all()
        .map_err(|e| format!("同步文件失败: {}", e))?;

    println!("[混淆] 完成: 原始头+偏移量已嵌入文件末尾 (28字节尾部数据)");
    Ok(())
}

/// 还原文件头：从文件末尾提取原始头并恢复
fn restore_header(file_path: &Path) -> Result<(), String> {
    if !file_path.exists() {
        return Err(format!("目标文件不存在: {}", file_path.display()));
    }

    // 读取末尾4字节检查魔术标记
    let mut file = File::open(file_path)
        .map_err(|e| format!("打开文件失败: {}", e))?;
    let file_size = file.metadata()
        .map_err(|e| format!("获取文件大小失败: {}", e))?
        .len();

    if file_size < 44 {
        // 文件太小，不可能包含混淆数据
        return Ok(());
    }

    file.seek(io::SeekFrom::End(-4))
        .map_err(|e| format!("定位文件末尾失败: {}", e))?;
    let mut magic = [0u8; 4];
    file.read_exact(&mut magic)
        .map_err(|e| format!("读取魔术标记失败: {}", e))?;

    if &magic != b"OBFS" {
        println!("[还原] 未找到混淆标记，文件可能未混淆或已还原");
        return Ok(());
    }

    println!("[还原] 检测到混淆标记，正在还原: {}", file_path.file_name().unwrap_or_default().to_string_lossy());

    // 读取末尾28字节 (原始头16 + 偏移量8 + OBFS4)
    file.seek(io::SeekFrom::End(-28))
        .map_err(|e| format!("定位尾部数据失败: {}", e))?;
    let mut tail_data = [0u8; 28];
    file.read_exact(&mut tail_data)
        .map_err(|e| format!("读取尾部数据失败: {}", e))?;

    // 提取原始头 (前16字节)
    let original_header = &tail_data[0..16];

    // 提取偏移量 (接下来8字节，小端序)
    let offset_bytes: [u8; 8] = tail_data[16..24].try_into()
        .map_err(|_| "偏移量数据长度不足")?;
    let orig_size = u64::from_le_bytes(offset_bytes);

    // 验证偏移量合理性
    if orig_size < 16 || orig_size > file_size {
        return Err(format!("偏移量异常 ({})，文件可能已损坏", orig_size));
    }

    // 写入原始头
    file.seek(io::SeekFrom::Start(0))
        .map_err(|e| format!("定位文件开头失败: {}", e))?;
    file.write_all(original_header)
        .map_err(|e| format!("还原文件头失败: {}", e))?;

    // 截断文件，去掉末尾28字节
    let new_size = file_size - 28;
    file.set_len(new_size)
        .map_err(|e| format!("截断文件失败: {}", e))?;

    file.sync_all()
        .map_err(|e| format!("同步文件失败: {}", e))?;

    println!("[还原] 完成: 原始头已恢复，尾部数据已移除");
    Ok(())
}

/// 检查文件是否被混淆
fn is_obfuscated(file_path: &Path) -> bool {
    if !file_path.exists() {
        return false;
    }

    let file_size = match fs::metadata(file_path) {
        Ok(m) => m.len(),
        Err(_) => return false,
    };

    if file_size < 44 {
        return false;
    }

    let mut file = match File::open(file_path) {
        Ok(f) => f,
        Err(_) => return false,
    };

    match file.seek(io::SeekFrom::End(-4)) {
        Ok(_) => {},
        Err(_) => return false,
    }

    let mut magic = [0u8; 4];
    match file.read_exact(&mut magic) {
        Ok(_) => &magic == b"OBFS",
        Err(_) => false,
    }
}

// ============================================================
// 备份列表
// ============================================================

/// 获取备份列表 (本地)
fn get_local_backups(config: &Config) -> Vec<BackupInfo> {
    let mut backups = Vec::new();

    if !config.backup_dir.exists() {
        return backups;
    }

    let entries = match fs::read_dir(&config.backup_dir) {
        Ok(e) => e,
        Err(_) => return backups,
    };

    for entry in entries.filter_map(Result::ok) {
        let path = entry.path();
        if !path.is_dir() {
            continue;
        }

        let name = path.file_name()
            .unwrap_or_default()
            .to_string_lossy()
            .to_string();

        // 跳过 temp 目录和备份目录本身
        if name == "tmp" || name == "backups" {
            continue;
        }

        // 获取大小
        let size = match get_dir_size(&path) {
            Ok(s) => format_size(s),
            Err(_) => "未知".to_string(),
        };

        // 获取修改时间
        let mtime = match path.metadata() {
            Ok(m) => {
                if let Ok(time) = m.modified() {
                    let datetime: chrono::DateTime<chrono::Local> = time.into();
                    datetime.format("%Y-%m-%d %H:%M:%S").to_string()
                } else {
                    "未知".to_string()
                }
            }
            Err(_) => "未知".to_string(),
        };

        backups.push(BackupInfo {
            name,
            size,
            mtime,
            is_local: true,
        });
    }

    // 按名称排序 (最新在前)
    backups.sort_by(|a, b| b.name.cmp(&a.name));
    backups
}

/// 获取备份列表 (网盘)
fn get_remote_backups(config: &Config) -> Vec<BackupInfo> {
    let mut backups = Vec::new();

    if !check_rclone_available(config) {
        return backups;
    }

    let remote_path = format!("{}:{}{}", config.rclone_remote, config.rclone_path, "/");
    let output = Command::new("rclone")
        .args(["lsf", &remote_path, "--dirs-only", "--max-depth", "1"])
        .output();

    let output = match output {
        Ok(o) if o.status.success() => String::from_utf8_lossy(&o.stdout).to_string(),
        _ => return backups,
    };

    for line in output.lines() {
        let name = line.trim();
        if name.is_empty() {
            continue;
        }

        // 获取大小
        let size_info = Command::new("rclone")
            .args(["size", &format!("{}:{}{}/{}", config.rclone_remote, config.rclone_path, "/", name), "--json"])
            .output();

        let size = if let Ok(o) = size_info {
            if o.status.success() {
                if let Ok(json) = String::from_utf8(o.stdout) {
                    if let Some(bytes) = parse_rclone_size(&json) {
                        format_size(bytes)
                    } else {
                        "未知".to_string()
                    }
                } else {
                    "未知".to_string()
                }
            } else {
                "未知".to_string()
            }
        } else {
            "未知".to_string()
        };

        // 获取修改时间
        let mtime = Command::new("rclone")
            .args(["lsf", &format!("{}:{}{}/{}", config.rclone_remote, config.rclone_path, "/", name),
                   "--format", "t", "--files-only", "--max-depth", "1"])
            .output();

        let mtime_str = if let Ok(o) = mtime {
            if o.status.success() {
                if let Ok(text) = String::from_utf8(o.stdout) {
                    text.lines().next()
                        .and_then(|line| line.split(';').nth(1))
                        .unwrap_or("未知")
                        .to_string()
                } else {
                    "未知".to_string()
                }
            } else {
                "未知".to_string()
            }
        } else {
            "未知".to_string()
        };

        backups.push(BackupInfo {
            name: name.to_string(),
            size,
            mtime: mtime_str,
            is_local: false,
        });
    }

    // 按名称排序 (最新在前)
    backups.sort_by(|a, b| b.name.cmp(&a.name));
    backups
}

/// 获取所有备份 (合并本地和网盘)
fn get_all_backups(config: &Config) -> Vec<BackupInfo> {
    let mut all = get_local_backups(config);
    all.extend(get_remote_backups(config));
    all
}

/// 通过序号获取备份名
fn get_backup_by_index(config: &Config, index: usize) -> Option<String> {
    let backups = get_all_backups(config);
    if index > 0 && index <= backups.len() {
        Some(backups[index - 1].name.clone())
    } else {
        None
    }
}

/// 判断备份位置
fn determine_backup_location(config: &Config, backup_arg: &str) -> Result<String, String> {
    // 如果是数字序号
    if let Ok(idx) = backup_arg.parse::<usize>() {
        if let Some(name) = get_backup_by_index(config, idx) {
            let local_path = config.backup_dir.join(&name);
            if local_path.exists() {
                return Ok("local".to_string());
            } else {
                return Ok("yun".to_string());
            }
        }
        return Err(format!("无效的序号: {}", backup_arg));
    }

    // 检查是否是本地路径
    let path = Path::new(backup_arg);
    if path.is_absolute() && path.exists() {
        return Ok("local".to_string());
    }

    // 检查是否在备份目录下
    let local_path = config.backup_dir.join(backup_arg);
    if local_path.exists() {
        return Ok("local".to_string());
    }

    // 检查是否是网盘备份
    if check_rclone_available(config) {
        let remote_path = format!("{}:{}{}/{}", config.rclone_remote, config.rclone_path, "/", backup_arg);
        let output = Command::new("rclone")
            .args(["lsf", &remote_path])
            .output();

        if let Ok(o) = output {
            if o.status.success() {
                return Ok("yun".to_string());
            }
        }
    }

    Err(format!("无法确定备份位置: {}", backup_arg))
}

// ============================================================
// 辅助函数
// ============================================================

/// 获取目录大小
fn get_dir_size(path: &Path) -> Result<u64, String> {
    let mut total = 0;
    for entry in walkdir::WalkDir::new(path)
        .into_iter()
        .filter_map(|e| e.ok())
    {
        if entry.file_type().is_file() {
            total += entry.metadata()
                .map_err(|e| format!("获取元数据失败: {}", e))?
                .len();
        }
    }
    Ok(total)
}

/// 格式化文件大小
fn format_size(bytes: u64) -> String {
    const KB: u64 = 1024;
    const MB: u64 = 1024 * KB;
    const GB: u64 = 1024 * MB;

    if bytes >= GB {
        format!("{:.2} GB", bytes as f64 / GB as f64)
    } else if bytes >= MB {
        format!("{:.2} MB", bytes as f64 / MB as f64)
    } else if bytes >= KB {
        format!("{:.2} KB", bytes as f64 / KB as f64)
    } else {
        format!("{} bytes", bytes)
    }
}

/// 解析 rclone size 输出
fn parse_rclone_size(json: &str) -> Option<u64> {
    if let Ok(v) = serde_json::from_str::<Value>(json) {
        if let Some(bytes) = v.get("bytes").and_then(|b| b.as_u64()) {
            return Some(bytes);
        }
    }
    None
}

/// 检查 rclone 是否可用
fn check_rclone_available(config: &Config) -> bool {
    let output = Command::new("rclone")
        .args(["listremotes"])
        .output();

    if let Ok(o) = output {
        if let Ok(text) = String::from_utf8(o.stdout) {
            return text.lines().any(|line| line == format!("{}:", config.rclone_remote));
        }
    }
    false
}

/// 检查并安装依赖
fn check_dependencies() -> Result<(), String> {
    let deps = ["tar", "zstd", "pv", "rclone", "jq", "openssl", "xxd", "md5sum", "sha256sum", "dd", "stat", "find"];
    let mut missing = Vec::new();

    for dep in &deps {
        if !command_exists(dep) {
            missing.push(*dep);
        }
    }

    if !missing.is_empty() {
        println!("缺少依赖: {:?}", missing);
        install_dependencies(&missing)?;
    }

    Ok(())
}

/// 检查命令是否存在
fn command_exists(cmd: &str) -> bool {
    which::which(cmd).is_ok()
}

/// 安装依赖 (自动检测发行版)
fn install_dependencies(missing: &[&str]) -> Result<(), String> {
    // Termux
    if let Ok(termux_version) = std::env::var("TERMUX_VERSION") {
        if !termux_version.is_empty() {
            println!("检测到 Termux 环境，使用 pkg 安装");
            let _ = Command::new("pkg").args(["update", "-y"]).status();
            let _ = Command::new("pkg").args(["upgrade", "-y"]).status();
            let _ = Command::new("pkg").args(["install", "-y", "zstd"]).status();

            for dep in missing {
                let pkg = match *dep {
                    "openssl" => "openssl-tool",
                    "xxd" => "vim",
                    "md5sum" | "sha256sum" | "dd" | "stat" => "coreutils",
                    "find" => "findutils",
                    _ => dep,
                };
                let _ = Command::new("pkg").args(["install", "-y", pkg]).status();
            }

            // 授予存储权限
            let _ = Command::new("termux-setup-storage").status();
            return Ok(());
        }
    }

    // 检测发行版
    if Path::new("/etc/alpine-release").exists() {
        println!("检测到 Alpine 系统，使用 apk 安装");
        let _ = Command::new("apk").args(["update"]).status();
        for dep in missing {
            let pkg = match *dep {
                "md5sum" | "sha256sum" => "coreutils",
                "xxd" => "vim",
                _ => dep,
            };
            let _ = Command::new("apk").args(["add", "--no-cache", pkg]).status();
        }
        return Ok(());
    }

    if Path::new("/etc/debian_version").exists() {
        println!("检测到 Debian/Ubuntu 系统，使用 apt 安装");
        let _ = Command::new("apt-get").args(["update", "-y"]).status();
        for dep in missing {
            let pkg = match *dep {
                "xxd" => "xxd",
                "md5sum" | "sha256sum" | "dd" | "stat" => "coreutils",
                "find" => "findutils",
                _ => dep,
            };
            let _ = Command::new("apt-get").args(["install", "-y", pkg]).status();
        }
        return Ok(());
    }

    if Path::new("/etc/redhat-release").exists() || Path::new("/etc/centos-release").exists() {
        println!("检测到 RHEL/CentOS 系统，使用 yum 安装");
        for dep in missing {
            let pkg = match *dep {
                "xxd" => "vim-common",
                "md5sum" | "sha256sum" | "dd" | "stat" => "coreutils",
                "find" => "findutils",
                _ => dep,
            };
            let _ = Command::new("yum").args(["install", "-y", pkg]).status();
        }
        return Ok(());
    }

    if Path::new("/etc/fedora-release").exists() {
        println!("检测到 Fedora 系统，使用 dnf 安装");
        for dep in missing {
            let pkg = match *dep {
                "xxd" => "vim-common",
                "md5sum" | "sha256sum" | "dd" | "stat" => "coreutils",
                "find" => "findutils",
                _ => dep,
            };
            let _ = Command::new("dnf").args(["install", "-y", pkg]).status();
        }
        return Ok(());
    }

    if Path::new("/etc/arch-release").exists() {
        println!("检测到 Arch Linux 系统，使用 pacman 安装");
        let _ = Command::new("pacman").args(["-Sy", "--noconfirm"]).status();
        for dep in missing {
            let pkg = match *dep {
                "xxd" => "vim",
                "md5sum" | "sha256sum" | "dd" | "stat" => "coreutils",
                "find" => "findutils",
                _ => dep,
            };
            let _ = Command::new("pacman").args(["-S", "--noconfirm", pkg]).status();
        }
        return Ok(());
    }

    if Path::new("/etc/SuSE-release").exists() || Path::new("/etc/openSUSE-release").exists() {
        println!("检测到 openSUSE 系统，使用 zypper 安装");
        for dep in missing {
            let pkg = match *dep {
                "xxd" => "vim",
                "md5sum" | "sha256sum" | "dd" | "stat" => "coreutils",
                "find" => "findutils",
                _ => dep,
            };
            let _ = Command::new("zypper").args(["install", "-y", pkg]).status();
        }
        return Ok(());
    }

    if cfg!(target_os = "macos") {
        println!("检测到 macOS 系统");
        if command_exists("brew") {
            for dep in missing {
                let _ = Command::new("brew").args(["install", dep]).status();
            }
            return Ok(());
        } else {
            return Err("未检测到 Homebrew，请先安装 Homebrew".to_string());
        }
    }

    Ok(())
}

/// 检查 rclone 配置
fn check_rclone_config(config: &Config) {
    let config_paths = [
        format!("{}/.config/rclone/rclone.conf", std::env::var("HOME").unwrap_or_default()),
        "/root/.config/rclone/rclone.conf".to_string(),
    ];

    let mut has_config = false;
    for path in &config_paths {
        if Path::new(path).exists() {
            has_config = true;
            break;
        }
    }

    if !has_config {
        println!("[!] rclone 配置文件不存在");
        println!(">>> 10 秒内按 Enter 进入 rclone 配置向导，否则自动跳过并继续 <<<");

        // 简单实现：等待用户输入或超时
        let mut input = String::new();
        if let Ok(_) = std::io::stdin().read_line(&mut input) {
            println!("[*] 启动 rclone 配置向导...");
            let _ = Command::new("rclone").arg("config").status();
            println!("[+] rclone 配置完成");
        } else {
            println!("[!] 超时未选择，跳过 rclone 配置，网盘功能不可用");
        }
    } else if !check_rclone_available(config) {
        println!("[!] 警告: rclone 配置文件存在但未配置远程 {}，网盘功能不可用", config.rclone_remote);
    } else {
        println!("[+] 已检测到 rclone 配置: {}", config.rclone_remote);
    }
}

/// 显示备份列表
fn show_backup_list(config: &Config) {
    let local_backups = get_local_backups(config);
    let remote_backups = get_remote_backups(config);

    // 显示本地备份
    println!("本地备份列表 ({}):", config.backup_dir.display());
    println!("----------------------------------------");
    if local_backups.is_empty() {
        println!("没有找到本地备份");
    } else {
        for (i, backup) in local_backups.iter().enumerate() {
            println!("{:2}. {} (大小: {}, 修改时间: {})",
                i + 1, backup.name, backup.size, backup.mtime);
        }
    }
    println!("----------------------------------------");
    println!("使用示例: {} -r {}/.../{}.aes [-to /custom/path]",
        env::args().next().unwrap_or_else(|| "./backup_restore".to_string()),
        config.backup_dir.display(),
        config.backup_prefix);
    println!("或使用序号: {} -r 1 [-to /custom/path]", env::args().next().unwrap_or_default());
    println!();

    // 显示网盘备份
    println!("网盘备份列表 ({}:{}):", config.rclone_remote, config.rclone_path);
    println!("----------------------------------------");
    if remote_backups.is_empty() {
        if check_rclone_available(config) {
            println!("没有找到网盘备份");
        } else {
            println!("网盘未配置，请先运行 'rclone config' 配置远程存储");
        }
    } else {
        let start_idx = local_backups.len();
        for (i, backup) in remote_backups.iter().enumerate() {
            println!("{:2}. {} (大小: {}, 修改时间: {})",
                start_idx + i + 1, backup.name, backup.size, backup.mtime);
        }
    }
    println!("----------------------------------------");
    println!("使用示例: {} -r {}{} [-to /custom/path]",
        env::args().next().unwrap_or_default(),
        config.backup_prefix,
        "20240101_120000");
    println!("或使用序号: {} -r {} [-to /custom/path]",
        env::args().next().unwrap_or_default(),
        local_backups.len() + 1);
}

/// 删除备份
fn delete_backup(config: &Config, arg: &str) -> Result<(), String> {
    // 安全检查：防止路径穿越
    if arg.contains("..") {
        return Err(format!("参数包含不安全的字符: {}", arg));
    }

    // 判断是数字序号还是路径
    if let Ok(idx) = arg.parse::<usize>() {
        let backups = get_all_backups(config);
        if idx == 0 || idx > backups.len() {
            return Err(format!("无效的序号: {}", arg));
        }

        let backup_name = &backups[idx - 1].name;
        println!("通过序号 {} 定位备份: {}", arg, backup_name);

        let local_path = config.backup_dir.join(backup_name);
        if local_path.exists() {
            println!("正在删除本地备份: {}", backup_name);
            fs::remove_dir_all(&local_path)
                .map_err(|e| format!("删除失败: {}", e))?;
            println!("本地备份删除成功");
        } else if check_rclone_available(config) {
            println!("本地未找到，尝试删除网盘备份: {}", backup_name);
            let remote_path = format!("{}:{}{}/{}", config.rclone_remote, config.rclone_path, "/", backup_name);
            let status = Command::new("rclone")
                .args(["purge", &remote_path])
                .status()
                .map_err(|e| format!("删除失败: {}", e))?;
            if !status.success() {
                return Err(format!("删除失败: 网盘中未找到 {}", backup_name));
            }
            println!("网盘备份删除成功");
        } else {
            return Err(format!("备份不存在且网盘未配置"));
        }
        return Ok(());
    }

    // 路径模式
    let path = Path::new(arg);
    if !path.exists() {
        return Err(format!("路径不存在: {}", arg));
    }

    if !path.is_dir() {
        return Err(format!("不是目录: {}", arg));
    }

    // 安全检查：禁止删除系统关键目录
    let dangerous = ["/", "/root", "/home", "/etc", "/bin", "/sbin", "/usr",
                     "/var", "/tmp", "/dev", "/proc", "/sys", "/storage",
                     "/storage/emulated", "/storage/emulated/0", "/data"];
    for d in &dangerous {
        if let Ok(real) = path.canonicalize() {
            if real == Path::new(d) {
                return Err(format!("禁止删除系统关键目录: {}", arg));
            }
        }
    }

    // 判断是否为备份格式
    let name = path.file_name().unwrap_or_default().to_string_lossy();
    let re = Regex::new(r"^(_?[a-zA-Z_]*)?[0-9]{8}_[0-9]{6}").unwrap();
    let is_backup_format = re.is_match(&name);

    // 非备份格式需要确认
    if !is_backup_format {
        println!("========================================");
        println!("警告: 该目录不是标准备份格式");
        println!("  {}", arg);
        println!("========================================");
        print!("确认删除？请输入 yes 继续: ");
        let _ = io::stdout().flush();
        let mut confirm = String::new();
        io::stdin().read_line(&mut confirm)
            .map_err(|e| format!("读取输入失败: {}", e))?;
        if confirm.trim() != "yes" {
            println!("已取消删除");
            return Ok(());
        }
    }

    // 执行删除
    println!("正在删除目录: {}", arg);
    fs::remove_dir_all(path)
        .map_err(|e| format!("删除失败: {}", e))?;
    println!("目录删除成功");

    // 检查网盘是否有同名备份
    if check_rclone_available(config) {
        let remote_path = format!("{}:{}{}/{}", config.rclone_remote, config.rclone_path, "/", name);
        let output = Command::new("rclone")
            .args(["lsf", &remote_path])
            .output();

        if let Ok(o) = output {
            if o.status.success() {
                println!("\n网盘中存在同名备份: {}", name);
                print!("是否一并删除网盘备份？(y/N): ");
                let _ = io::stdout().flush();
                let mut answer = String::new();
                io::stdin().read_line(&mut answer)
                    .map_err(|e| format!("读取输入失败: {}", e))?;
                if answer.trim().to_lowercase() == "y" {
                    let _ = Command::new("rclone").args(["purge", &remote_path]).status();
                    println!("网盘备份已删除");
                } else {
                    println!("跳过网盘删除");
                }
            }
        }
    }

    Ok(())
}

/// 解析大小字符串 (如 "100M", "1G")
fn parse_size(s: &str) -> Result<u64, String> {
    let s = s.trim();
    if s.is_empty() {
        return Err("大小字符串为空".to_string());
    }

    let num_part: String = s.chars().take_while(|c| c.is_ascii_digit()).collect();
    let num: u64 = num_part.parse().map_err(|_| format!("无效的数字: {}", num_part))?;

    let unit = &s[num_part.len()..];
    match unit.to_uppercase().as_str() {
        "" | "B" => Ok(num),
        "K" | "KB" => Ok(num * 1024),
        "M" | "MB" => Ok(num * 1024 * 1024),
        "G" | "GB" => Ok(num * 1024 * 1024 * 1024),
        _ => Err(format!("未知的单位: {}", unit)),
    }
}

/// 校验分割文件
fn verify_split_files(backup_dir: &Path, backup_name: &str) -> Result<(), String> {
    println!("正在校验分割文件...");

    // 检查校验文件
    let md5_path = backup_dir.join("checksums.md5");
    let sha_path = backup_dir.join("checksums.sha256");

    if !md5_path.exists() {
        println!("警告: 找不到MD5校验文件，跳过MD5校验");
    } else {
        println!("正在进行MD5校验:");
        let output = Command::new("md5sum")
            .args(["-c"])
            .current_dir(backup_dir)
            .arg(&md5_path)
            .output()
            .map_err(|e| format!("执行MD5校验失败: {}", e))?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(format!("MD5校验失败: {}", stderr));
        }

        let stdout = String::from_utf8_lossy(&output.stdout);
        for line in stdout.lines() {
            if line.contains(&format!("{}{}", backup_name, SPLIT_SUFFIX)) ||
               line.contains(&format!("{}.", backup_name)) {
                println!("  {}", line);
            }
        }
    }

    if !sha_path.exists() {
        println!("警告: 找不到SHA256校验文件，跳过SHA256校验");
    } else {
        println!("正在进行SHA256校验:");
        let output = Command::new("sha256sum")
            .args(["-c"])
            .current_dir(backup_dir)
            .arg(&sha_path)
            .output()
            .map_err(|e| format!("执行SHA256校验失败: {}", e))?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(format!("SHA256校验失败: {}", stderr));
        }

        let stdout = String::from_utf8_lossy(&output.stdout);
        for line in stdout.lines() {
            if line.contains(&format!("{}{}", backup_name, SPLIT_SUFFIX)) ||
               line.contains(&format!("{}.", backup_name)) {
                println!("  {}", line);
            }
        }
    }

    println!("所有分割文件校验通过");
    Ok(())
}

/// 比较本地和远程文件差异，下载缺失的文件
fn compare_and_download(
    config: &Config,
    remote_dir: &str,
    local_dir: &Path,
) -> Result<(), String> {
    let remote_path = format!("{}:{}{}/{}", config.rclone_remote, config.rclone_path, "/", remote_dir);

    // 获取远程文件列表
    let output = Command::new("rclone")
        .args(["lsf", &remote_path, "--files-only", "--format", "p"])
        .output()
        .map_err(|e| format!("获取远程文件列表失败: {}", e))?;

    let remote_files = String::from_utf8_lossy(&output.stdout);
    let mut missing = Vec::new();

    for file in remote_files.lines() {
        let file = file.trim();
        if file.is_empty() {
            continue;
        }
        let local_file = local_dir.join(file);
        if !local_file.exists() {
            missing.push(file.to_string());
        }
    }

    if missing.is_empty() {
        println!("所有文件已存在本地，无需下载");
        return Ok(());
    }

    println!("发现 {} 个文件需要下载...", missing.len());
    for file in &missing {
        println!("正在下载缺失文件: {}", file);
        let status = Command::new("rclone")
            .args(["copy", &format!("{}/{}", remote_path, file), &local_dir.to_string_lossy()])
            .args(["--user-agent", config.user_agent.as_str()])
            .status()
            .map_err(|e| format!("下载失败: {}", e))?;

        if !status.success() {
            return Err(format!("下载失败: {}", file));
        }
    }

    Ok(())
}

// ============================================================
// 核心功能: 备份
// ============================================================

/// 执行备份
fn perform_backup(
    config: &mut Config,
    target_dir: &str,
    backup_name: Option<&str>,
    upload_after_backup: bool,
) -> Result<(), String> {
    let timestamp = Local::now().format("%Y%m%d_%H%M%S").to_string();
    let default_name = format!("{}{}", config.backup_prefix, timestamp);
    let backup_name_str = backup_name.unwrap_or(&default_name);
    let backup_folder = config.backup_dir.join(backup_name_str);

    println!("[{}] 开始备份流程 (密码: 已设置)", Local::now().format("%Y-%m-%d %H:%M:%S"));
    println!("  目标: {}", target_dir);
    println!("  输出: {}", backup_folder.display());

    // 创建备份目录
    fs::create_dir_all(&backup_folder)
        .map_err(|e| format!("创建备份目录失败: {}", e))?;

    // 构建加密文件的基础名
    let enc_file_base = backup_folder.join(backup_name_str);

    // 创建密码临时文件
    let password_file = create_password_tempfile(&config.password)?;
    let password_path = password_file.path();

    // 执行备份管道: tar -> pv -> zstd -> openssl -> split
    let target_dir_path = Path::new(target_dir);
    let target_parent = target_dir_path.parent().unwrap_or(Path::new(""));
    let target_name = target_dir_path.file_name()
        .ok_or("无法获取目录名")?
        .to_string_lossy();

    // 启动 tar 进程
    let mut tar_cmd = Command::new("tar")
        .args(["-cf", "-"])
        .args(["-C", &target_parent.to_string_lossy()])
        .arg(target_name.as_ref())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("启动 tar 失败: {}", e))?;

    let mut current_stdout = tar_cmd.stdout.take().ok_or("无法获取 tar 输出")?;

    // zstd 压缩
    let mut zstd_cmd = Command::new("zstd")
        .args([format!("-{}", config.zstd_level).as_str(), "-q", "-c"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("启动 zstd 失败: {}", e))?;

    let mut zstd_stdin = zstd_cmd.stdin.take().ok_or("无法获取 zstd 输入")?;
    let zstd_stdout = zstd_cmd.stdout.take().ok_or("无法获取 zstd 输出")?;

    // 复制数据到 zstd
    let mut buffer = [0u8; 65536];
    loop {
        let n = current_stdout.read(&mut buffer)
            .map_err(|e| format!("读取 tar 输出失败: {}", e))?;
        if n == 0 {
            break;
        }
        zstd_stdin.write_all(&buffer[..n])
            .map_err(|e| format!("写入 zstd 失败: {}", e))?;
    }
    drop(zstd_stdin);

    // openssl 加密
    let mut openssl_cmd = Command::new("openssl")
        .args(["enc", format!("-{}", config.cipher_alg).as_str(),
               "-pbkdf2", format!("-iter{}", config.pbkdf2_iter).as_str(),
               "-pass", format!("file:{}", password_path.display()).as_str(),
               "-e"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("启动 openssl 失败: {}", e))?;

    let mut openssl_stdin = openssl_cmd.stdin.take().ok_or("无法获取 openssl 输入")?;
    let openssl_stdout = openssl_cmd.stdout.take().ok_or("无法获取 openssl 输出")?;

    // 复制数据到 openssl
    let mut zstd_reader = BufReader::new(zstd_stdout);
    let mut buffer = [0u8; 65536];
    loop {
        let n = zstd_reader.read(&mut buffer)
            .map_err(|e| format!("读取 zstd 输出失败: {}", e))?;
        if n == 0 {
            break;
        }
        openssl_stdin.write_all(&buffer[..n])
            .map_err(|e| format!("写入 openssl 失败: {}", e))?;
    }
    drop(openssl_stdin);

    // 等待 openssl 完成并获取输出
    let openssl_output = openssl_cmd.wait_with_output()
        .map_err(|e| format!("等待 openssl 失败: {}", e))?;

    if !openssl_output.status.success() {
        return Err("openssl 加密失败".to_string());
    }

    // 分割加密后的数据
    let encrypted_data = openssl_output.stdout;
    let chunk_size = config.split_size.clone();

    // 清除可能存在的旧分割文件
    let prefix_str = enc_file_base.to_string_lossy();
    let pattern = format!("{}.*{}", prefix_str, config.split_suffix);
    for entry in glob::glob(&pattern).map_err(|e| format!("glob 错误: {}", e))? {
        if let Ok(path) = entry {
            let _ = fs::remove_file(&path);
        }
    }

    let mut chunks = Vec::new();
    let size_bytes = parse_size(&chunk_size)?;
    let mut chunk_num = 1;
    let mut offset = 0;

    while offset < encrypted_data.len() {
        let end = std::cmp::min(offset + size_bytes as usize, encrypted_data.len());
        let chunk_data = &encrypted_data[offset..end];

        let chunk_file = if chunks.is_empty() && chunk_num == 1 && end == encrypted_data.len() {
            // 只有一个分片
            format!("{}{}", prefix_str, config.split_suffix)
        } else {
            format!("{}.{:03}{}", prefix_str, chunk_num, config.split_suffix)
        };

        fs::write(&chunk_file, chunk_data)
            .map_err(|e| format!("写入分片 {} 失败: {}", chunk_num, e))?;
        chunks.push(PathBuf::from(&chunk_file));

        offset = end;
        chunk_num += 1;
    }

    // 检查是否成功生成文件
    if chunks.is_empty() {
        return Err("备份失败: 没有生成任何分片文件".to_string());
    }

    println!("备份流程完成");

    // 文件头混淆
    if config.obfuscate_header {
        let clean_prefix = enc_file_base.to_string_lossy();
        let file_001 = format!("{}.001{}", clean_prefix, config.split_suffix);
        let file_001_path = Path::new(&file_001);

        if file_001_path.exists() {
            println!("[混淆] 检测到分片文件，正在混淆 001 文件头...");
            obfuscate_header(file_001_path)?;
        } else {
            let single_file = format!("{}{}", clean_prefix, config.split_suffix);
            let single_path = Path::new(&single_file);
            if single_path.exists() {
                println!("[混淆] 文件未分割，直接混淆单文件头...");
                obfuscate_header(single_path)?;
            } else {
                println!("警告: 未找到可混淆的文件");
            }
        }
        println!("[混淆] 文件头混淆处理完成");
    } else {
        println!("[混淆] 文件头混淆已禁用 (OBFUSCATE_HEADER=false)");
    }

    // 创建校验文件
    println!("正在创建校验文件...");
    let md5_path = backup_folder.join("checksums.md5");
    let sha_path = backup_folder.join("checksums.sha256");

    // 删除旧的校验文件
    let _ = fs::remove_file(&md5_path);
    let _ = fs::remove_file(&sha_path);

    let mut md5_output = Vec::new();
    let mut sha_output = Vec::new();

    for entry in fs::read_dir(&backup_folder)
        .map_err(|e| format!("读取备份目录失败: {}", e))?
    {
        let entry = entry.map_err(|e| format!("读取目录项失败: {}", e))?;
        let file_name = entry.file_name().to_string_lossy().to_string();

        if file_name == "checksums.md5" || file_name == "checksums.sha256" {
            continue;
        }

        let file_path = entry.path();
        if file_path.is_file() {
            // MD5
            let output = Command::new("md5sum")
                .arg(&file_path)
                .output()
                .map_err(|e| format!("计算 MD5 失败: {}", e))?;
            md5_output.extend_from_slice(&output.stdout);

            // SHA256
            let output = Command::new("sha256sum")
                .arg(&file_path)
                .output()
                .map_err(|e| format!("计算 SHA256 失败: {}", e))?;
            sha_output.extend_from_slice(&output.stdout);
        }
    }

    fs::write(&md5_path, &md5_output)
        .map_err(|e| format!("写入 MD5 校验文件失败: {}", e))?;
    fs::write(&sha_path, &sha_output)
        .map_err(|e| format!("写入 SHA256 校验文件失败: {}", e))?;

    println!("校验文件创建完成");

    // 复制脚本自身到备份目录
    let script_path = env::current_exe()
        .ok()
        .and_then(|p| p.canonicalize().ok());

    if let Some(script) = script_path {
        let dest = backup_folder.join("backup_restore");
        if let Err(e) = fs::copy(&script, &dest) {
            println!("[!] 复制备份脚本到备份目录失败: {}", e);
        } else {
            println!("[*] 已将备份脚本复制到备份目录");
        }
    }

    // 上传到网盘
    if upload_after_backup {
        if check_rclone_available(config) {
            println!("正在上传到网盘...");
            let remote_path = format!("{}:{}{}/{}", config.rclone_remote, config.rclone_path, "/", backup_name_str);

            let _ = Command::new("rclone")
                .args(["mkdir", &remote_path])
                .status();

            let status = Command::new("rclone")
                .args(["copy", &backup_folder.to_string_lossy(), &remote_path])
                .args(["--user-agent", &config.user_agent])
                .status()
                .map_err(|e| format!("上传失败: {}", e))?;

            if !status.success() {
                return Err("上传失败!".to_string());
            }
            println!("上传完成");
        } else {
            println!("[!] 跳过上传：网盘未配置");
        }
    }

    // 清理旧备份 (本地)
    println!("清理旧备份（保留最新{}份，仅处理{}前缀）...",
        config.keep_latest, config.backup_prefix);

    let mut backups: Vec<PathBuf> = Vec::new();
    for entry in fs::read_dir(&config.backup_dir)
        .map_err(|e| format!("读取备份目录失败: {}", e))?
    {
        let entry = entry.map_err(|e| format!("读取目录项失败: {}", e))?;
        let path = entry.path();
        if path.is_dir() {
            if let Some(name) = path.file_name() {
                let name = name.to_string_lossy();
                if name.starts_with(&config.backup_prefix) && name != backup_name_str {
                    backups.push(path);
                }
            }
        }
    }

    backups.sort_by(|a, b| a.file_name().cmp(&b.file_name()));
    backups.reverse();

    for dir in backups.iter().skip(config.keep_latest) {
        let _ = fs::remove_dir_all(dir);
    }

    // 清理网盘旧备份
    if check_rclone_available(config) {
        println!("清理网盘旧备份...");
        let remote_root = format!("{}:{}{}", config.rclone_remote, config.rclone_path, "/");
        let output = Command::new("rclone")
            .args(["lsd", &remote_root])
            .output()
            .map_err(|e| format!("获取网盘目录列表失败: {}", e))?;

        let mut remote_backups = Vec::new();
        if let Ok(text) = String::from_utf8(output.stdout) {
            for line in text.lines() {
                let parts: Vec<&str> = line.split_whitespace().collect();
                if parts.len() >= 5 {
                    let name = parts[4];
                    if name.starts_with(&config.backup_prefix) && name != backup_name_str {
                        remote_backups.push(name.to_string());
                    }
                }
            }
        }

        remote_backups.sort();
        remote_backups.reverse();

        for name in remote_backups.iter().skip(config.keep_latest) {
            let remote_path = format!("{}:{}{}/{}", config.rclone_remote, config.rclone_path, "/", name);
            let _ = Command::new("rclone").args(["purge", &remote_path]).status();
        }
    }

    println!("[{}] 备份完成: {}", Local::now().format("%Y-%m-%d %H:%M:%S"), backup_name_str);
    println!("备份位置: {}", backup_folder.display());

    Ok(())
}

// ============================================================
// 核心功能: 还原
// ============================================================

/// 执行还原
fn perform_restore(
    config: &mut Config,
    backup_arg: &str,
    restore_to: Option<&str>,
) -> Result<(), String> {
    let restore_path = match restore_to {
        Some(path) => PathBuf::from(path),
        None => config.restore_dir.clone(),
    };

    println!("开始还原流程...");

    // 确定备份位置
    let mode = determine_backup_location(config, backup_arg)?;

    // 获取备份名称
    let backup_name = if let Ok(idx) = backup_arg.parse::<usize>() {
        if let Some(name) = get_backup_by_index(config, idx) {
            name
        } else {
            return Err(format!("无效的序号: {}", backup_arg));
        }
    } else {
        backup_arg.trim_end_matches('/').to_string()
    };

    println!("使用备份: {}", backup_name);

    // 创建恢复目录
    fs::create_dir_all(&restore_path)
        .map_err(|e| format!("无法创建恢复目录: {}", e))?;

    // 构建备份路径
    let backup_dir = if mode == "yun" {
        // 网盘模式：下载到临时目录
        let temp_dir = config.temp_dir.join(&backup_name);
        fs::create_dir_all(&temp_dir)
            .map_err(|e| format!("创建临时目录失败: {}", e))?;

        if !check_rclone_available(config) {
            return Err("错误: 网盘未配置，无法从网盘还原".to_string());
        }

        let remote_path = format!("{}:{}{}/{}", config.rclone_remote, config.rclone_path, "/", backup_name);

        // 检查本地已有文件
        let local_files = fs::read_dir(&temp_dir)
            .ok()
            .map(|d| d.filter_map(|e| e.ok()).count())
            .unwrap_or(0);

        if local_files > 0 {
            println!("发现本地已有部分文件，开始对比并下载缺失文件...");
            compare_and_download(config, &backup_name, &temp_dir)?;
        } else {
            println!("正在从网盘下载备份文件...");
            let status = Command::new("rclone")
                .args(["copy", &remote_path, &temp_dir.to_string_lossy()])
                .args(["--user-agent", &config.user_agent])
                .status()
                .map_err(|e| format!("下载失败: {}", e))?;

            if !status.success() {
                return Err("下载失败!".to_string());
            }
        }

        temp_dir
    } else {
        // 本地模式：解析路径
        let path = Path::new(backup_arg);
        if path.is_absolute() && path.exists() {
            path.to_path_buf()
        } else {
            config.backup_dir.join(&backup_name)
        }
    };

    // 查找备份文件
    let backup_prefix = backup_dir.join(&backup_name);
    let backup_prefix_str = backup_prefix.to_string_lossy();

    // 检查分片文件
    let pattern = format!("{}.???.{}", backup_prefix_str, config.split_suffix);
    let has_parts = !glob::glob(&pattern)
        .map_err(|e| format!("glob 错误: {}", e))?
        .filter_map(|e| e.ok())
        .collect::<Vec<_>>()
        .is_empty();

    let single_file_name = format!("{}{}", backup_prefix_str, config.split_suffix);
    let single_file_path = Path::new(&single_file_name);
    let has_single = single_file_path.exists();

    if !has_parts && !has_single {
        // 尝试旧格式 (含 .aes)
        let old_prefix = format!("{}.aes", backup_prefix_str);
        let old_pattern = format!("{}.???.{}", old_prefix, config.split_suffix);
        let old_has_parts = !glob::glob(&old_pattern)
            .map_err(|e| format!("glob 错误: {}", e))?
            .filter_map(|e| e.ok())
            .collect::<Vec<_>>()
            .is_empty();

        let old_single_name = format!("{}{}", old_prefix, config.split_suffix);
        let old_single = Path::new(&old_single_name);
        let old_has_single = old_single.exists();

        if old_has_parts || old_has_single {
            println!("检测到旧格式备份文件（含.aes），兼容处理中...");
            return perform_restore_old_format(config, &backup_dir, &old_prefix, &restore_path);
        } else {
            return Err("找不到备份文件".to_string());
        }
    }

    // 检查是否需要还原文件头
    let file_001_name = format!("{}.001{}", backup_prefix_str, config.split_suffix);
    let file_001_path = Path::new(&file_001_name);
    let need_restore = if file_001_path.exists() {
        is_obfuscated(file_001_path)
    } else if single_file_path.exists() {
        is_obfuscated(single_file_path)
    } else {
        false
    };

    // 校验
    if need_restore {
        println!("[校验] 检测到001文件仍为混淆状态，执行完整性校验...");
        verify_split_files(&backup_dir, &backup_name)?;
    } else {
        println!("[校验] 001文件已还原或无混淆，跳过校验");
    }

    // 还原文件头
    if need_restore {
        if file_001_path.exists() {
            println!("[还原] 校验通过，正在还原001文件头...");
            restore_header(file_001_path)?;
            println!("[还原] 001文件头还原完成");
        } else if single_file_path.exists() {
            println!("[还原] 校验通过，正在还原单文件头...");
            restore_header(single_file_path)?;
            println!("[还原] 单文件头还原完成");
        }
    }

    // 执行还原管道: cat(分片) -> openssl(解密) -> zstd(解压) -> tar(提取)
    println!("正在执行 合并 -> 解密 -> 解压...");

    let password_file = create_password_tempfile(&config.password)?;
    let password_path = password_file.path();

    // 确定合并源
    let merge_prefix = if Path::new(&format!("{}.001{}", backup_prefix_str, config.split_suffix)).exists() {
        backup_prefix_str.to_string()
    } else {
        backup_prefix_str.to_string()
    };

    let mut final_success = false;

    // 分片模式
    if has_parts {
        // 合并分片文件 - 使用 shell glob
        let glob_pattern = format!("{}.*{}", merge_prefix, config.split_suffix);
        let mut cat_cmd = Command::new("sh");
        cat_cmd.args(["-c", &format!("cat {}", glob_pattern)])
            .stdout(Stdio::piped())
            .stderr(Stdio::null());

        let mut cat_child = cat_cmd.spawn()
            .map_err(|e| format!("启动 cat 失败: {}", e))?;

        let cat_stdout = cat_child.stdout.take().ok_or("无法获取 cat 输出")?;

        // openssl 解密
        let mut openssl_cmd = Command::new("openssl")
            .args(["enc", "-d", format!("-{}", config.cipher_alg).as_str(),
                   "-pbkdf2", format!("-iter{}", config.pbkdf2_iter).as_str(),
                   "-pass", format!("file:{}", password_path.display()).as_str()])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("启动 openssl 失败: {}", e))?;

        let mut openssl_stdin = openssl_cmd.stdin.take().ok_or("无法获取 openssl 输入")?;
        let _openssl_stdout = openssl_cmd.stdout.take().ok_or("无法获取 openssl 输出")?;

        // 复制数据到 openssl
        let mut reader = BufReader::new(cat_stdout);
        let mut buffer = [0u8; 65536];
        loop {
            let n = reader.read(&mut buffer)
                .map_err(|e| format!("读取 cat 输出失败: {}", e))?;
            if n == 0 {
                break;
            }
            openssl_stdin.write_all(&buffer[..n])
                .map_err(|e| format!("写入 openssl 失败: {}", e))?;
        }
        drop(openssl_stdin);

        // zstd 解压
        let mut zstd_cmd = Command::new("zstd")
            .args(["-d", "-q", "-c"])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("启动 zstd 失败: {}", e))?;

        let mut zstd_stdin = zstd_cmd.stdin.take().ok_or("无法获取 zstd 输入")?;
        let zstd_stdout = zstd_cmd.stdout.take().ok_or("无法获取 zstd 输出")?;

        // 复制数据到 zstd
        let mut openssl_reader = BufReader::new(_openssl_stdout);
        let mut buffer = [0u8; 65536];
        loop {
            let n = openssl_reader.read(&mut buffer)
                .map_err(|e| format!("读取 openssl 输出失败: {}", e))?;
            if n == 0 {
                break;
            }
            zstd_stdin.write_all(&buffer[..n])
                .map_err(|e| format!("写入 zstd 失败: {}", e))?;
        }
        drop(zstd_stdin);

        // tar 提取
        let mut tar_cmd = Command::new("tar")
            .args(["-x", "--warning=no-timestamp", "-C", &restore_path.to_string_lossy()])
            .stdin(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("启动 tar 失败: {}", e))?;

        let mut tar_stdin = tar_cmd.stdin.take().ok_or("无法获取 tar 输入")?;

        // 复制数据到 tar
        let mut zstd_reader = BufReader::new(zstd_stdout);
        let mut buffer = [0u8; 65536];
        loop {
            let n = zstd_reader.read(&mut buffer)
                .map_err(|e| format!("读取 zstd 输出失败: {}", e))?;
            if n == 0 {
                break;
            }
            tar_stdin.write_all(&buffer[..n])
                .map_err(|e| format!("写入 tar 失败: {}", e))?;
        }
        drop(tar_stdin);

        // 等待所有子进程完成
        let tar_status = tar_cmd.wait()
            .map_err(|e| format!("等待 tar 失败: {}", e))?;

        let zstd_status = zstd_cmd.wait()
            .map_err(|e| format!("等待 zstd 失败: {}", e))?;

        let openssl_status = openssl_cmd.wait()
            .map_err(|e| format!("等待 openssl 失败: {}", e))?;

        let cat_status = cat_child.wait()
            .map_err(|e| format!("等待 cat 失败: {}", e))?;

        if !cat_status.success() {
            return Err("文件合并失败!".to_string());
        }
        if !openssl_status.success() {
            return Err("解密失败! 请检查密码是否正确。".to_string());
        }
        if !zstd_status.success() {
            return Err("zstd 解压失败!".to_string());
        }
        if !tar_status.success() {
            return Err("tar 解包失败!".to_string());
        }

        final_success = true;
    }

    // 单文件模式
    if has_single && !final_success {
        let input_file = format!("{}{}", merge_prefix, config.split_suffix);

        // openssl 解密
        let mut openssl_cmd = Command::new("openssl")
            .args(["enc", "-d", format!("-{}", config.cipher_alg).as_str(),
                   "-pbkdf2", format!("-iter{}", config.pbkdf2_iter).as_str(),
                   "-pass", format!("file:{}", password_path.display()).as_str(),
                   "-in", &input_file])
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("启动 openssl 失败: {}", e))?;

        let openssl_stdout = openssl_cmd.stdout.take().ok_or("无法获取 openssl 输出")?;

        // zstd 解压
        let mut zstd_cmd = Command::new("zstd")
            .args(["-d", "-q", "-c"])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("启动 zstd 失败: {}", e))?;

        let mut zstd_stdin = zstd_cmd.stdin.take().ok_or("无法获取 zstd 输入")?;
        let zstd_stdout = zstd_cmd.stdout.take().ok_or("无法获取 zstd 输出")?;

        // 复制数据到 zstd
        let mut reader = BufReader::new(openssl_stdout);
        let mut buffer = [0u8; 65536];
        loop {
            let n = reader.read(&mut buffer)
                .map_err(|e| format!("读取 openssl 输出失败: {}", e))?;
            if n == 0 {
                break;
            }
            zstd_stdin.write_all(&buffer[..n])
                .map_err(|e| format!("写入 zstd 失败: {}", e))?;
        }
        drop(zstd_stdin);

        // tar 提取
        let mut tar_cmd = Command::new("tar")
            .args(["-x", "--warning=no-timestamp", "-C", &restore_path.to_string_lossy()])
            .stdin(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("启动 tar 失败: {}", e))?;

        let mut tar_stdin = tar_cmd.stdin.take().ok_or("无法获取 tar 输入")?;

        // 复制数据到 tar
        let mut zstd_reader = BufReader::new(zstd_stdout);
        let mut buffer = [0u8; 65536];
        loop {
            let n = zstd_reader.read(&mut buffer)
                .map_err(|e| format!("读取 zstd 输出失败: {}", e))?;
            if n == 0 {
                break;
            }
            tar_stdin.write_all(&buffer[..n])
                .map_err(|e| format!("写入 tar 失败: {}", e))?;
        }
        drop(tar_stdin);

        // 等待所有子进程完成
        let tar_status = tar_cmd.wait()
            .map_err(|e| format!("等待 tar 失败: {}", e))?;

        let zstd_status = zstd_cmd.wait()
            .map_err(|e| format!("等待 zstd 失败: {}", e))?;

        let openssl_status = openssl_cmd.wait()
            .map_err(|e| format!("等待 openssl 失败: {}", e))?;

        if !openssl_status.success() {
            return Err("解密失败! 请检查密码是否正确。".to_string());
        }
        if !zstd_status.success() {
            return Err("zstd 解压失败!".to_string());
        }
        if !tar_status.success() {
            return Err("tar 解包失败!".to_string());
        }

        final_success = true;
    }

    if !final_success {
        return Err("找不到备份文件".to_string());
    }

    println!("还原流程完成，未产生中间文件");

    // 清理临时下载目录 (网盘模式)
    if mode == "yun" {
        let _ = fs::remove_dir_all(&backup_dir);
    }

    println!("还原成功! 文件已恢复到: {}", restore_path.display());

    Ok(())
}

/// 还原旧格式备份 (含 .aes)
fn perform_restore_old_format(
    config: &mut Config,
    _backup_dir: &Path,
    old_prefix: &str,
    restore_path: &Path,
) -> Result<(), String> {
    let password_file = create_password_tempfile(&config.password)?;
    let password_path = password_file.path();

    // 检查分片文件
    let old_pattern = format!("{}.*.{}", old_prefix, config.split_suffix);
    let has_parts = !glob::glob(&old_pattern)
        .map_err(|e| format!("glob 错误: {}", e))?
        .filter_map(|e| e.ok())
        .collect::<Vec<_>>()
        .is_empty();

    let old_single_name = format!("{}{}", old_prefix, config.split_suffix);
    let old_single = Path::new(&old_single_name);
    let has_single = old_single.exists();

    if !has_parts && !has_single {
        return Err("找不到备份文件".to_string());
    }

    println!("正在执行 合并 -> 解密 -> 解压...");

    if has_parts {
        // 分片模式
        let glob_pattern = format!("{}.*.{}", old_prefix, config.split_suffix);
        let mut cat_cmd = Command::new("sh");
        cat_cmd.args(["-c", &format!("cat {}", glob_pattern)])
            .stdout(Stdio::piped())
            .stderr(Stdio::null());

        let mut cat_child = cat_cmd.spawn()
            .map_err(|e| format!("启动 cat 失败: {}", e))?;

        let cat_stdout = cat_child.stdout.take().ok_or("无法获取 cat 输出")?;

        // openssl 解密
        let mut openssl_cmd = Command::new("openssl")
            .args(["enc", "-d", format!("-{}", config.cipher_alg).as_str(),
                   "-pbkdf2", format!("-iter{}", config.pbkdf2_iter).as_str(),
                   "-pass", format!("file:{}", password_path.display()).as_str()])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("启动 openssl 失败: {}", e))?;

        let mut openssl_stdin = openssl_cmd.stdin.take().ok_or("无法获取 openssl 输入")?;
        let openssl_stdout = openssl_cmd.stdout.take().ok_or("无法获取 openssl 输出")?;

        let mut reader = BufReader::new(cat_stdout);
        let mut buffer = [0u8; 65536];
        loop {
            let n = reader.read(&mut buffer)
                .map_err(|e| format!("读取 cat 输出失败: {}", e))?;
            if n == 0 {
                break;
            }
            openssl_stdin.write_all(&buffer[..n])
                .map_err(|e| format!("写入 openssl 失败: {}", e))?;
        }
        drop(openssl_stdin);

        // zstd 解压
        let mut zstd_cmd = Command::new("zstd")
            .args(["-d", "-q", "-c"])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("启动 zstd 失败: {}", e))?;

        let mut zstd_stdin = zstd_cmd.stdin.take().ok_or("无法获取 zstd 输入")?;
        let zstd_stdout = zstd_cmd.stdout.take().ok_or("无法获取 zstd 输出")?;

        let mut openssl_reader = BufReader::new(openssl_stdout);
        let mut buffer = [0u8; 65536];
        loop {
            let n = openssl_reader.read(&mut buffer)
                .map_err(|e| format!("读取 openssl 输出失败: {}", e))?;
            if n == 0 {
                break;
            }
            zstd_stdin.write_all(&buffer[..n])
                .map_err(|e| format!("写入 zstd 失败: {}", e))?;
        }
        drop(zstd_stdin);

        // tar 提取
        let mut tar_cmd = Command::new("tar")
            .args(["-x", "--warning=no-timestamp", "-C", &restore_path.to_string_lossy()])
            .stdin(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(|e| format!("启动 tar 失败: {}", e))?;

        let mut tar_stdin = tar_cmd.stdin.take().ok_or("无法获取 tar 输入")?;

        let mut zstd_reader = BufReader::new(zstd_stdout);
        let mut buffer = [0u8; 65536];
        loop {
            let n = zstd_reader.read(&mut buffer)
                .map_err(|e| format!("读取 zstd 输出失败: {}", e))?;
            if n == 0 {
                break;
            }
            tar_stdin.write_all(&buffer[..n])
                .map_err(|e| format!("写入 tar 失败: {}", e))?;
        }
        drop(tar_stdin);

        let tar_status = tar_cmd.wait()
            .map_err(|e| format!("等待 tar 失败: {}", e))?;
        let zstd_status = zstd_cmd.wait()
            .map_err(|e| format!("等待 zstd 失败: {}", e))?;
        let openssl_status = openssl_cmd.wait()
            .map_err(|e| format!("等待 openssl 失败: {}", e))?;
        let cat_status = cat_child.wait()
            .map_err(|e| format!("等待 cat 失败: {}", e))?;

        if !cat_status.success() {
            return Err("文件合并失败!".to_string());
        }
        if !openssl_status.success() {
            return Err("解密失败! 请检查密码是否正确。".to_string());
        }
        if !zstd_status.success() {
            return Err("zstd 解压失败!".to_string());
        }
        if !tar_status.success() {
            return Err("tar 解包失败!".to_string());
        }

        println!("还原成功! 文件已恢复到: {}", restore_path.display());
        return Ok(());
    }

    // 单文件模式
    let input_file = format!("{}{}", old_prefix, config.split_suffix);

    let mut openssl_cmd = Command::new("openssl")
        .args(["enc", "-d", format!("-{}", config.cipher_alg).as_str(),
               "-pbkdf2", format!("-iter{}", config.pbkdf2_iter).as_str(),
               "-pass", format!("file:{}", password_path.display()).as_str(),
               "-in", &input_file])
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("启动 openssl 失败: {}", e))?;

    let openssl_stdout = openssl_cmd.stdout.take().ok_or("无法获取 openssl 输出")?;

    let mut zstd_cmd = Command::new("zstd")
        .args(["-d", "-q", "-c"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("启动 zstd 失败: {}", e))?;

    let mut zstd_stdin = zstd_cmd.stdin.take().ok_or("无法获取 zstd 输入")?;
    let zstd_stdout = zstd_cmd.stdout.take().ok_or("无法获取 zstd 输出")?;

    let mut reader = BufReader::new(openssl_stdout);
    let mut buffer = [0u8; 65536];
    loop {
        let n = reader.read(&mut buffer)
            .map_err(|e| format!("读取 openssl 输出失败: {}", e))?;
        if n == 0 {
            break;
        }
        zstd_stdin.write_all(&buffer[..n])
            .map_err(|e| format!("写入 zstd 失败: {}", e))?;
    }
    drop(zstd_stdin);

    let mut tar_cmd = Command::new("tar")
        .args(["-x", "--warning=no-timestamp", "-C", &restore_path.to_string_lossy()])
        .stdin(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("启动 tar 失败: {}", e))?;

    let mut tar_stdin = tar_cmd.stdin.take().ok_or("无法获取 tar 输入")?;

    let mut zstd_reader = BufReader::new(zstd_stdout);
    let mut buffer = [0u8; 65536];
    loop {
        let n = zstd_reader.read(&mut buffer)
            .map_err(|e| format!("读取 zstd 输出失败: {}", e))?;
        if n == 0 {
            break;
        }
        tar_stdin.write_all(&buffer[..n])
            .map_err(|e| format!("写入 tar 失败: {}", e))?;
    }
    drop(tar_stdin);

    let tar_status = tar_cmd.wait()
        .map_err(|e| format!("等待 tar 失败: {}", e))?;
    let zstd_status = zstd_cmd.wait()
        .map_err(|e| format!("等待 zstd 失败: {}", e))?;
    let openssl_status = openssl_cmd.wait()
        .map_err(|e| format!("等待 openssl 失败: {}", e))?;

    if !openssl_status.success() {
        return Err("解密失败! 请检查密码是否正确。".to_string());
    }
    if !zstd_status.success() {
        return Err("zstd 解压失败!".to_string());
    }
    if !tar_status.success() {
        return Err("tar 解包失败!".to_string());
    }

    println!("还原成功! 文件已恢复到: {}", restore_path.display());
    Ok(())
}

// ============================================================
// 手动上传
// ============================================================

fn manual_upload(config: &mut Config, arg: Option<&str>) -> Result<(), String> {
    if !check_rclone_available(config) {
        return Err("错误: 网盘未配置，无法上传".to_string());
    }

    let dir_to_upload = if let Some(idx_str) = arg {
        if let Ok(idx) = idx_str.parse::<usize>() {
            // 通过序号查找
            let backups = get_local_backups(config);
            if idx == 0 || idx > backups.len() {
                return Err(format!("无效的序号: {}", idx));
            }
            let name = &backups[idx - 1].name;
            let path = config.backup_dir.join(name);
            if path.exists() && path.is_dir() {
                path
            } else {
                return Err(format!("本地备份不存在: {}", name));
            }
        } else {
            // 路径模式
            let path = Path::new(idx_str);
            if path.exists() && path.is_dir() {
                path.to_path_buf()
            } else {
                return Err(format!("目录不存在: {}", idx_str));
            }
        }
    } else {
        // 自动查找最新备份
        let mut latest: Option<PathBuf> = None;
        for entry in fs::read_dir(&config.backup_dir)
            .map_err(|e| format!("读取备份目录失败: {}", e))?
        {
            let entry = entry.map_err(|e| format!("读取目录项失败: {}", e))?;
            let path = entry.path();
            if path.is_dir() {
                if let Some(name) = path.file_name() {
                    let name = name.to_string_lossy();
                    if name.starts_with(&config.backup_prefix) {
                        if let Some(ref current) = latest {
                            if name > current.file_name().unwrap_or_default().to_string_lossy() {
                                latest = Some(path);
                            }
                        } else {
                            latest = Some(path);
                        }
                    }
                }
            }
        }

        match latest {
            Some(path) => path,
            None => return Err("找不到可用的备份目录".to_string()),
        }
    };

    let backup_name = dir_to_upload.file_name()
        .ok_or("无法获取目录名")?
        .to_string_lossy()
        .to_string();

    println!("[{}] 开始上传备份: {}", Local::now().format("%Y-%m-%d %H:%M:%S"), backup_name);

    // 检查目录是否为空
    let is_empty = fs::read_dir(&dir_to_upload)
        .map_err(|e| format!("读取目录失败: {}", e))?
        .next()
        .is_none();

    if is_empty {
        return Err(format!("备份目录为空: {}", dir_to_upload.display()));
    }

    // 显示目录内容
    println!("目录内容:");
    let entries: Vec<_> = fs::read_dir(&dir_to_upload)
        .map_err(|e| format!("读取目录失败: {}", e))?
        .filter_map(|e| e.ok())
        .collect();

    for entry in entries.iter().take(10) {
        let name = entry.file_name();
        let size = entry.metadata()
            .ok()
            .map(|m| if m.is_file() { format_size(m.len()) } else { "DIR".to_string() })
            .unwrap_or_else(|| "?".to_string());
        println!("  {} ({})", name.to_string_lossy(), size);
    }

    if entries.len() > 10 {
        println!("  ... 还有 {} 个文件", entries.len() - 10);
    }

    // 上传到网盘
    println!("正在上传到网盘...");
    let remote_path = format!("{}:{}{}/{}", config.rclone_remote, config.rclone_path, "/", backup_name);

    let _ = Command::new("rclone")
        .args(["mkdir", &remote_path])
        .status();

    let status = Command::new("rclone")
        .args(["copy", &dir_to_upload.to_string_lossy(), &remote_path])
        .args(["--progress", "--user-agent", &config.user_agent])
        .status()
        .map_err(|e| format!("上传失败: {}", e))?;

    if !status.success() {
        return Err("上传失败!".to_string());
    }

    println!("[{}] 上传完成: {}", Local::now().format("%Y-%m-%d %H:%M:%S"), backup_name);
    Ok(())
}

// ============================================================
// 备份指定目录
// ============================================================

fn backup_specific_directory(
    config: &mut Config,
    dir_to_backup: &str,
    upload_after_backup: bool,
    custom_backup_dir: Option<&str>,
) -> Result<(), String> {
    let path = Path::new(dir_to_backup);
    if !path.exists() || !path.is_dir() {
        return Err(format!("目录不存在: {}", dir_to_backup));
    }

    if upload_after_backup && !check_rclone_available(config) {
        return Err("错误: 网盘未配置，无法上传".to_string());
    }

    let dir_name = path.file_name()
        .ok_or("无法获取目录名")?
        .to_string_lossy()
        .to_string();

    let timestamp = Local::now().format("%Y%m%d_%H%M%S").to_string();
    let backup_name = format!("{}_{}", dir_name, timestamp);

    println!("开始备份指定目录: {} (密码: 已设置)", dir_to_backup);
    println!("正在执行备份: {}", backup_name);

    // 保存原始备份目录
    let original_backup_dir = config.backup_dir.clone();

    // 如果指定了自定义输出目录
    if let Some(custom_dir) = custom_backup_dir {
        config.backup_dir = PathBuf::from(custom_dir);
    }

    let result = perform_backup(config, dir_to_backup, Some(&backup_name), upload_after_backup);

    // 恢复原始备份目录
    config.backup_dir = original_backup_dir;

    if result.is_ok() {
        println!("指定目录备份完成");
    }

    result
}

// ============================================================
// 参数解析
// ============================================================

struct Args {
    interactive: bool,
    command: CommandType,
}

enum CommandType {
    Default,
    Restore { backup_arg: String, restore_to: Option<String> },
    List,
    Help,
    Upload { arg: Option<String> },
    Delete { arg: String },
    SpecificDir { dir: String, upload: bool, output_dir: Option<String> },
}

impl Args {
    fn parse() -> Result<Self, String> {
        let args: Vec<String> = env::args().skip(1).collect();
        let mut interactive = false;
        let mut command = CommandType::Default;

        let mut i = 0;
        while i < args.len() {
            match args[i].as_str() {
                "-pwd" => {
                    interactive = true;
                    i += 1;
                }
                "-r" => {
                    i += 1;
                    if i >= args.len() {
                        return Err("必须指定备份路径或序号".to_string());
                    }
                    let backup_arg = args[i].clone();
                    i += 1;

                    let mut restore_to = None;
                    if i < args.len() && args[i] == "-to" {
                        i += 1;
                        if i >= args.len() {
                            return Err("必须指定恢复路径".to_string());
                        }
                        restore_to = Some(args[i].clone());
                        i += 1;
                    }

                    command = CommandType::Restore { backup_arg, restore_to };
                }
                "-list" => {
                    command = CommandType::List;
                    i += 1;
                }
                "-h" | "--help" => {
                    command = CommandType::Help;
                    i += 1;
                }
                "-up" => {
                    i += 1;
                    let arg = if i < args.len() {
                        let next = &args[i];
                        if !next.starts_with('-') {
                            let val = Some(next.clone());
                            i += 1;
                            val
                        } else {
                            None
                        }
                    } else {
                        None
                    };
                    command = CommandType::Upload { arg };
                }
                "-del" => {
                    i += 1;
                    if i >= args.len() {
                        return Err("必须指定序号或路径".to_string());
                    }
                    let arg = args[i].clone();
                    i += 1;
                    command = CommandType::Delete { arg };
                }
                "-sd" => {
                    i += 1;
                    if i >= args.len() {
                        return Err("必须指定目录路径".to_string());
                    }
                    let dir = args[i].clone();
                    i += 1;

                    let mut upload = false;
                    let mut output_dir = None;

                    while i < args.len() {
                        match args[i].as_str() {
                            "-to" => {
                                i += 1;
                                if i >= args.len() {
                                    return Err("必须指定备份输出目录".to_string());
                                }
                                output_dir = Some(args[i].clone());
                                i += 1;
                            }
                            "-up" => {
                                upload = true;
                                i += 1;
                            }
                            _ => {
                                i += 1;
                            }
                        }
                    }

                    command = CommandType::SpecificDir { dir, upload, output_dir };
                }
                _ => {
                    return Err(format!("未知参数: {}", args[i]));
                }
            }
        }

        Ok(Args { interactive, command })
    }
}

// ============================================================
// 显示帮助
// ============================================================

fn show_help() {
    println!("用法:");
    println!("  {} [-h] [-list] [-r 备份路径/序号] [-to 恢复路径] [-up 目录] [-del 序号] [-sd 目录] [-pwd]",
        env::args().next().unwrap_or_else(|| "./backup_restore".to_string()));
    println!();
    println!("示例命令:");
    println!("1. 执行备份（使用默认密码）:");
    println!("   {}", env::args().next().unwrap_or_default());
    println!();
    println!("2. 执行备份（交互式输入密码）:");
    println!("   {} -pwd", env::args().next().unwrap_or_default());
    println!();
    println!("3. 从本地备份还原:");
    println!("   {} -r $HOME/backups/{}{}/{} {}.aes [-to /custom/restore/path]",
        env::args().next().unwrap_or_default(),
        BACKUP_PREFIX,
        "20240101_120000",
        BACKUP_PREFIX,
        "20240101_120000");
    println!("   或使用序号: {} -r 1 [-to /custom/restore/path]", env::args().next().unwrap_or_default());
    println!();
    println!("4. 从网盘备份还原:");
    println!("   {} -r {}{} [-to /custom/restore/path]",
        env::args().next().unwrap_or_default(),
        BACKUP_PREFIX,
        "20240101_120000");
    println!("   或使用序号: {} -r 5 [-to /custom/restore/path]", env::args().next().unwrap_or_default());
    println!();
    println!("5. 显示备份列表:");
    println!("   {} -list", env::args().next().unwrap_or_default());
    println!();
    println!("6. 删除备份:");
    println!("   {} -del 1 (删除序号1的备份)", env::args().next().unwrap_or_default());
    println!();
    println!("7. 手动上传指定目录:");
    println!("   {} -up /path/to/directory [-pwd]", env::args().next().unwrap_or_default());
    println!();
    println!("8. 备份指定目录:");
    println!("   {} -sd /path/to/directory [-pwd] [-up]", env::args().next().unwrap_or_default());
    println!();
    println!("9. 显示帮助:");
    println!("   {} -h", env::args().next().unwrap_or_default());
    println!();
    println!("密码说明:");
    println!("  - 不带 -pwd 参数: 使用脚本内置默认密码");
    println!("  - 带 -pwd 参数: 触发交互式安全输入（输入不可见）");
    println!("  - 密码绝不会出现在命令行历史或进程列表中");
    println!();
    println!("文件头混淆说明:");
    println!("  - 001文件(或单文件)的OpenSSL头(Salted__)会被替换为ZIP头");
    println!("  - 原始16字节头+偏移量嵌在文件末尾(28字节尾部)");
    println!("  - 还原时自动检测并恢复原始头");
    println!("  - 可通过 OBFUSCATE_HEADER 变量开关此功能");
}

// ============================================================
// 主函数
// ============================================================

fn main() {
    let args = match Args::parse() {
        Ok(a) => a,
        Err(e) => {
            eprintln!("{}", e);
            show_help();
            std::process::exit(1);
        }
    };

    let mut config = Config::default();

    // 初始化目录
    if let Err(e) = fs::create_dir_all(&config.backup_dir) {
        eprintln!("创建备份目录失败: {}", e);
        std::process::exit(1);
    }
    if let Err(e) = fs::create_dir_all(&config.restore_dir) {
        eprintln!("创建恢复目录失败: {}", e);
        std::process::exit(1);
    }
    if let Err(e) = fs::create_dir_all(&config.temp_dir) {
        eprintln!("创建临时目录失败: {}", e);
        std::process::exit(1);
    }

    // 检查依赖
    if let Err(e) = check_dependencies() {
        eprintln!("依赖检查失败: {}", e);
        std::process::exit(1);
    }

    // 检查 rclone 配置
    check_rclone_config(&config);

    // 处理密码
    if let Err(e) = get_password(&mut config, args.interactive) {
        eprintln!("{}", e);
        std::process::exit(1);
    }

    // 执行命令
    let auto_upload = config.auto_upload;
    let result = match args.command {
        CommandType::Default => {
            // 默认执行备份
            let target = config.target_dir.clone();
            perform_backup(&mut config, &target, None, auto_upload)
        }
        CommandType::Restore { backup_arg, restore_to } => {
            perform_restore(&mut config, &backup_arg, restore_to.as_deref())
        }
        CommandType::List => {
            show_backup_list(&config);
            Ok(())
        }
        CommandType::Help => {
            show_help();
            Ok(())
        }
        CommandType::Upload { arg } => {
            manual_upload(&mut config, arg.as_deref())
        }
        CommandType::Delete { arg } => {
            delete_backup(&config, &arg)
        }
        CommandType::SpecificDir { dir, upload, output_dir } => {
            backup_specific_directory(&mut config, &dir, upload, output_dir.as_deref())
        }
    };

    if let Err(e) = result {
        eprintln!("错误: {}", e);
        std::process::exit(1);
    }
}